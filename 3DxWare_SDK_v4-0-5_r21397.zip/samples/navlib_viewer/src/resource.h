//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by navlib_viewer.rc
//
#define IDD_ABOUTBOX 100
#define IDR_MAINFRAME 128
#define IDS_About 129
#define IDS_Perspective 130
#define IDS_Parallel 131
#define IDS_2D 132
#define IDS_ToggleGrid 133
#define IDS_OpenFile 134
#define IDS_SelectNone 135
#define IDS_File 136
#define IDS_View 137
#define IDS_Projection 138
#define IDS_ABOUT_DESCRIPTION 1067
#define IDC_ABOUT_DESCRIPTION 1067
#define IDS_ABOUT_TITLE 1068
#define ID_PROJECTION_PERSPECTIVE 32777
#define ID_PROJECTION_PARALLEL 32778
#define ID_PROJECTION_2D 32779
#define ID_VIEW_SHOWGRID 32780

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS 1
#define _APS_NEXT_RESOURCE_VALUE 139
#define _APS_NEXT_COMMAND_VALUE 32781
#define _APS_NEXT_CONTROL_VALUE 1068
#define _APS_NEXT_SYMED_VALUE 101
#endif
#endif
